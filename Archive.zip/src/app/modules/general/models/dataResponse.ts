export class DataResponse {
    message: string = '';
    contenu: any = null;
    data: any=null;
    body?: Blob;
}
