import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-footerAdmin',
  templateUrl: './footerAdmin.component.html',
  styleUrls: ['./footerAdmin.component.css']
})
export class FooterAdminComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
