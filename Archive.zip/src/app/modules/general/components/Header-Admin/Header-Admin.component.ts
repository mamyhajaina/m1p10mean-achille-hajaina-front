import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-Header-Admin',
  templateUrl: './Header-Admin.component.html',
  styleUrls: ['./Header-Admin.component.css']
})
export class HeaderAdminComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
