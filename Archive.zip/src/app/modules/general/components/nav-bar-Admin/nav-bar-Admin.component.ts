import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nav-bar-Admin',
  templateUrl: './nav-bar-Admin.component.html',
  styleUrls: ['./nav-bar-Admin.component.css']
})
export class NavBarAdminComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
