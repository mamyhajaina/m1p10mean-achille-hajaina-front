import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employe',
  templateUrl: './employe.component.html',
  styleUrls: ['./employe.component.css', './../../../assets/assets/css/style.css']
})
export class EmployeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
