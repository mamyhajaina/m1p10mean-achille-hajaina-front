import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-prise-rendez-vous',
  templateUrl: './prise-rendez-vous.component.html',
  styleUrls: ['./prise-rendez-vous.component.css']
})
export class PriseRendezVousComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
