import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  {  },
];

export const ManagerRoutes = RouterModule.forChild(routes);
